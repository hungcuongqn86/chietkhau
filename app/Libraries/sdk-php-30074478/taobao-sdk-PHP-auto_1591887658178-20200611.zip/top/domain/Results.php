<?php

/**
 * data
 * @author auto create
 */
class Results
{
	
	/** 
	 * data
	 **/
	public $data;	
}
?>