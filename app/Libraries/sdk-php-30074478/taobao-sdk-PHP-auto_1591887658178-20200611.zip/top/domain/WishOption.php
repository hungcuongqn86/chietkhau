<?php

/**
 * 参数
 * @author auto create
 */
class WishOption
{
	
	/** 
	 * 清单id
	 **/
	public $wish_list_id;	
}
?>